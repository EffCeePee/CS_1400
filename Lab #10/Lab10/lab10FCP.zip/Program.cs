﻿// File Prologue
// Name: Franklin Colton Parry
// Section: 601
// Project: Lab 10
// Date:  2/12/13


// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

using System;

class Program
{
    static void Main()
    {
        // Declare Constants that will be used for the limits of the dice        
        // Declare variables for numbers generated from the random number generator
        // Create a random number generator object
        // Tell the user what the program does
        // Ask the user if the want to roll the dice and store the answer in a variable
        // create a loop that validates if the input was valid or not
        // If it is invalid input display a warning message and move to ask for data again
        // If the data is valid and yes Generate two random numbers and store them in the variables
        // Begin a loop to start over if the user wants to roll the dice again when finished
        // create two random numbers and store them as variables  
        // Create an conditional statement to display "you rolled boxcars" if the numbers are 6 and 6
        // Else if they rolled 1 and 1 display "you rolled snake eyes"
        // Else display the two numbers generated.  
        // Return to the beginning to ask if they would like to roll the dice again.
        // create a loop to validate the user input
        // If it is invalid input display a warning message and move to ask for data again
        // If the data is valid and no print a goodbye message and quit


        Console.ReadLine();
    }//End Main()
}//End class Program