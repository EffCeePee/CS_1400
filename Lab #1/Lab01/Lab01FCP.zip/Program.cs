﻿// File Prologue
// Name: Franklin Colton Parry
// Project: Lab01"
// Date: 1/09/2012

// I declare that the following source code was written by me, or provided 
// by the instructor for this project. I understand that copying 
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

using System;


class Program
{
    static void Main()
    {
        // This program displays my student information
        string name = "Franklin Colton Parry";
        string course = "CNS 1400";
        string section = "601";
        string project = "Lab One";

        // This coded inserts the strings into the stream object cout
        Console.WriteLine("Name: {0}", name);
        Console.WriteLine("Course: {0}", course);
        Console.WriteLine("Section: {0}", section);
        Console.WriteLine("Project: {0}", project);


        Console.ReadLine();
    }// End Main
}  // End Class Program