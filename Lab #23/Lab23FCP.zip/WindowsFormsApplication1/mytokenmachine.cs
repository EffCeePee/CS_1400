﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class MyTokenMachine
    {

        // declare variables
        private int tokenCount;
        private int quarterCount;


        // default constructor 

        public TokenMachine( )
        {

        tokenCount = 100;
        quarterCount = 0;

        }


        //method
        




    }
}
